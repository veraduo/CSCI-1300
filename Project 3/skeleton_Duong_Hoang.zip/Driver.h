// CS1300 Spring 2020
// Author: Vera Duong and Emily Hoang
// Recitation: 301 – Telly Umada
// Project 3 

#ifndef DRIVER_H
#define DRIVER_H

#include <iostream> 
#include "Boss.h"
#include "Kirby.h"
#include "Minion.h"
using namespace std; 

class Driver
{
    private:

        string items[5]; // Will create a text file for the store
        int itemCost[5]; // Points will determine which items the user can buy
        int actionCount; // odd is Kirby, even is Boss
        int points; // Points will be determined by the number of minions defeated
        
    public:

        void bossAttack(); // The attack value and defense value will be picked at random
        void block(); // Boss and kirby can block. Weakens the damage from an attack
        void kirbyAttack();//Attack value will be assigned at random. Energy will be taken from kirby
        void kirbyDodge();// Whether kirby completely dodges an attack or not will be determined randomly
        void displayMenu();
        void visitStore(string storeFile, string inventoryFile); // Reading from the storeFile and writing to the inventoryFile
        void viewEnemy();// Displays description of the enemy
        void viewInventory(string inventoryFile);//Displays the items kirby has in his inventory
        void displayKirbyStats();
        void displayEnemyStats();
     
}; 

#endif