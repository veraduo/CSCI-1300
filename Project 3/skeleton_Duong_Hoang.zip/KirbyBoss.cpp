// CS1300 Spring 2020
// Author: Vera Duong and Emily Hoang
// Recitation: 301 – Telly Umada
// Project 3

#include <iostream> 
#include "KirbyBoss.h"
using namespace std; 

KirbyBoss::KirbyBoss()
{
    health = 100;
    attackValue = 100;
    defenseValue = 100;
    energy = 100;
}

void KirbyBoss::setHealth(int health_)
{
    health = health_;
}

int KirbyBoss::getHealth()
{
    return health;
}

void KirbyBoss::setAttackValue(int attackValue_)
{
    attackValue = attackValue_;
}
int KirbyBoss :: getAttackValue()
{
    return attackValue;
}

void KirbyBoss :: setDefenseValue(int defenseValue_)
{
    defenseValue = defenseValue_;
}

int KirbyBoss::getDefenseValue()
{
    return defenseValue;
}

void KirbyBoss :: setEnergy(int energy_)
{
    energy = energy_;
}
int KirbyBoss :: getEnergy()
{
    return energy;
}

