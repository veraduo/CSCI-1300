// CS1300 Spring 2020
// Author: Vera Duong and Emily Hoang
// Recitation: 301 – Telly Umada
// Project 3 

#ifndef MINION_H
#define MINION_H

#include <iostream> 
using namespace std; 

class Minion
{
    private: 

        int sword;
        int shield;
        
    public: 

        Minion();
        
        void setShield(int shield_);
        int getShield();

        void setSword(int sword_);
        int getSword();


}; 

#endif