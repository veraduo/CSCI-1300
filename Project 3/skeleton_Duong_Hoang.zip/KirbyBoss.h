// CS1300 Spring 2020
// Author: Vera Duong and Emily Hoang
// Recitation: 301 – Telly Umada
// Project 3 

#ifndef KIRBYBOSS_H
#define KIRBYBOSS_H

#include <iostream> 
using namespace std; 

class KirbyBoss //this class will be used for both Kirby and the Boss
{
    private: 

        int health;
        int attackValue;
        int defenseValue;
        int energy; 
        
    public: 

        KirbyBoss();

        void setHealth(int health_);
        int getHealth();

        void setAttackValue(int attackValue_);
        int getAttackValue();

        void setDefenseValue(int defenseValue_);
        int getDefenseValue();

        void setEnergy(int energy_);
        int getEnergy();

        int copy(int minionValue); 
}; 

#endif