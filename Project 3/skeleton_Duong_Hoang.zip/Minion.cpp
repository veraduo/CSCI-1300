// CS1300 Spring 2020
// Author: Vera Duong and Emily Hoang
// Recitation: 301 – Telly Umada
// Project 3

#include <iostream> 
#include "Minion.h"
using namespace std; 

Minion::Minion()
{
    shield = 100;
    sword = 100;
}

void Minion::setShield(int shield_)
{
    shield = shield_;
}

int Minion::getShield()
{
    return shield;
}

void Minion::setSword(int sword_)
{
    sword = sword_;
}

int Minion::getSword()
{
    return sword;
}
